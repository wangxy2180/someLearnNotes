# obj_detected

- 应该是需要创建package，然后把src里的内容和msg，xml，CMakeLists复制过去就可以把
- 程序源文件 `src/obj_detected.cpp`

## 一些信息

- 程序没有输入参数
- 作为订阅者，程序默认接收qhd(960*540)图像，订阅topic为`"/kinect2/qhd/image_color_rect"`和`"/kinect2/qhd/image_depth_rect"`
- 作为发布者，发布的topic名为`"/obj_detect/tennis_pose"`

## 使用方法：

1. 先开启bridge

```
roslaunch kinect2_bridge kinect2_bridge.launch
```

2. 开启obj_detected

```
rosrun obj_detected obj_detected
```

3. 可以先用下命令进行topic查看

```
rostopic echo /obj_detect/tennis_pose
```
或者使用下列命令将其重定向到文件output.txt中，并同时在屏幕输出
```
rostopic echo /obj_detect/tennis_pose > &1 | tee output.txt
```


